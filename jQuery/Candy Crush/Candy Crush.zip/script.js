<script>
$(document).ready(function() {
    $("img").click(function(event){
        $(this).hide();
    });

    $("button").click(function(event){
        $("*").show();
    });

});
</script>


